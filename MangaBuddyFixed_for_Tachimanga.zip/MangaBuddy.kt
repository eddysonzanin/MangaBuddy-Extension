package eu.kanade.tachiyomi.extension.en.mangabuddy

import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.online.ParsedHttpSource
import eu.kanade.tachiyomi.network.GET
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import okhttp3.Request
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

class MangaBuddy : ParsedHttpSource() {

    override val name = "MangaBuddy (English)"
    override val baseUrl = "https://mangabuddy.com"
    override val lang = "en"
    override val supportsLatest = true

    // Popular
    override fun popularMangaRequest(page: Int): Request =
        GET("$baseUrl/hot?page=$page", headers)

    override fun popularMangaSelector() = "div.manga-list div.book-item"
    override fun popularMangaFromElement(element: Element) = SManga.create().apply {
        title = element.select("a.book-name").text()
        thumbnail_url = element.select("img").attr("abs:data-src")
        url = element.select("a.book-name").attr("abs:href")
    }
    override fun popularMangaNextPageSelector() = "a.page-link[rel=next]"

    // Latest
    override fun latestUpdatesRequest(page: Int): Request =
        GET("$baseUrl/latest?page=$page", headers)
    override fun latestUpdatesSelector() = popularMangaSelector()
    override fun latestUpdatesFromElement(element: Element) = popularMangaFromElement(element)
    override fun latestUpdatesNextPageSelector() = popularMangaNextPageSelector()

    // Search
    override fun searchMangaRequest(page: Int, query: String, filters: eu.kanade.tachiyomi.source.filter.FilterList): Request =
        GET("$baseUrl/search?keyword=$query&page=$page", headers)
    override fun searchMangaSelector() = popularMangaSelector()
    override fun searchMangaFromElement(element: Element) = popularMangaFromElement(element)
    override fun searchMangaNextPageSelector() = popularMangaNextPageSelector()

    // Details
    override fun mangaDetailsParse(document: Document) = SManga.create().apply {
        title = document.select("h1").text()
        author = document.select("span:contains(Author:)").next().text()
        genre = document.select("a[href*=/genre/]").joinToString { it.text() }
        description = document.select("div.summary__content").text()
        thumbnail_url = document.select("div.book-thumbnail img").attr("abs:data-src")
    }

    // Chapters
    override fun chapterListSelector() = "ul.main li.chapter-item"
    override fun chapterFromElement(element: Element) = SChapter.create().apply {
        name = element.select("a").text()
        url = element.select("a").attr("abs:href")
    }

    // Pages
    override fun pageListParse(document: Document): List<Page> =
        document.select("img.page-img").mapIndexed { i, el ->
            Page(i, "", el.attr("abs:data-src"))
        }

    override fun imageUrlParse(document: Document): String =
        document.select("img.page-img").attr("abs:data-src")
}
